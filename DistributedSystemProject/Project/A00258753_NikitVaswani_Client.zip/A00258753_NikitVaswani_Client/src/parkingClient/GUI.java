package parkingClient;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.Savepoint;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.apache.http.client.ClientProtocolException;

import javax.swing.JButton;
import javax.swing.JTextArea;

public class GUI implements ActionListener {

	private JFrame frmValetParkingSystem;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JButton btnPark,btnDeliver,btnUpdate;
	private JTextArea textArea;
	private JButton btnCreateDB;
	private JButton btnNewButton;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI window = new GUI();
					window.frmValetParkingSystem.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws Exception 
	 */
	public GUI() throws Exception {
		initialize();
	}
	public void getInfo() {
		try {
			textArea.setText(GetParkingDetails.Details().toString());
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	/**
	 * Initialize the contents of the frame.
	 * @throws Exception 
	 */
	private void initialize() throws Exception {
		frmValetParkingSystem = new JFrame();
		frmValetParkingSystem.setTitle("Valet Parking System");
		frmValetParkingSystem.setBounds(100, 100, 693, 477);
		frmValetParkingSystem.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmValetParkingSystem.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setBounds(86, 103, 23, 16);
		frmValetParkingSystem.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setBounds(62, 132, 56, 16);
		frmValetParkingSystem.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Car Number:");
		lblNewLabel_2.setBounds(36, 161, 82, 16);
		frmValetParkingSystem.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Area Parked:");
		lblNewLabel_3.setBounds(27, 202, 82, 16);
		frmValetParkingSystem.getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(128, 100, 116, 22);
		frmValetParkingSystem.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(128, 129, 116, 22);
		frmValetParkingSystem.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(130, 158, 116, 22);
		frmValetParkingSystem.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(128, 199, 116, 22);
		frmValetParkingSystem.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		 btnPark = new JButton("Park");
		btnPark.setBounds(36, 262, 97, 25);
		frmValetParkingSystem.getContentPane().add(btnPark);
		btnPark.addActionListener(this);
		
		 btnDeliver = new JButton("Deliver");
		btnDeliver.setBounds(145, 262, 97, 25);
		frmValetParkingSystem.getContentPane().add(btnDeliver);
		btnDeliver.addActionListener(this);
		
		 btnUpdate = new JButton("Update");
		btnUpdate.setBounds(88, 311, 97, 25);
		frmValetParkingSystem.getContentPane().add(btnUpdate);
		
		textArea = new JTextArea();
		textArea.setBounds(268, 58, 395, 278);
		frmValetParkingSystem.getContentPane().add(textArea);
		
		btnCreateDB = new JButton("Create DB");
		btnCreateDB.setBounds(409, 368, 97, 25);
		frmValetParkingSystem.getContentPane().add(btnCreateDB);
		btnCreateDB.addActionListener(this);
		
		btnUpdate.addActionListener(this);
		getInfo();
		
		textField.setText("12");
		textField_1.setText("Nial");
		textField_2.setText("ABCD-1234");
		textField_3.setText("10");
		
	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object target = e.getSource();
		int id,area;
		String name, numb;
		id = Integer.parseInt(textField.getText());
		name = textField_1.getText();
		numb = textField_2.getText();
		area = Integer.parseInt(textField_3.getText());
		if(target==btnDeliver) {
			DeleteItem d = new DeleteItem();
			try {
				d.testIntegrityUnicityError(id);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			textArea.setText("");
			getInfo();
		}
		else if(target==btnPark) {
			InsertClient.insert(id, name, numb, area);
			System.out.println("Inserted");
			textArea.setText("");
			getInfo();
			
		}
		else if(target==btnUpdate) {
			UpdateItem up = new UpdateItem();
			
			try {
				up.updateCarData(id, name, numb, area);
			} catch (ClientProtocolException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (URISyntaxException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			textArea.setText("");
			getInfo();
		}
		else if(target==btnCreateDB) {
			CreateDB cdb = new CreateDB();
			cdb.create();
		}
		
		
	}
}
