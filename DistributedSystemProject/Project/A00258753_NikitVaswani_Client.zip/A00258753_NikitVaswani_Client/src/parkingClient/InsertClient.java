package parkingClient;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

public class InsertClient {

	public static void insert(int id, String name,String numb, int area) {
		try {
		CloseableHttpResponse response = null;
		URI uri = new URIBuilder()
				.setScheme("http")
				.setHost("localhost")
				.setPort(8082)
				.setPath("/A00258753_NikitVaswani/valetParking/ParkingService/items").build();
		
		HttpPost httpPost = new HttpPost(uri);
		httpPost.setHeader("Accept","text/html");
		CloseableHttpClient client = HttpClients.createDefault();
		
	List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
	nameValuePairs.add(new BasicNameValuePair("id",String.valueOf(id)));
	nameValuePairs.add(new BasicNameValuePair("name",name));
	nameValuePairs.add(new BasicNameValuePair("numb",numb));
	nameValuePairs.add(new BasicNameValuePair("area",String.valueOf(area)));
	httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
	
	response = client.execute(httpPost);
	System.out.println(response.toString());
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
