package parkingClient;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

public class UpdateItem {



	public static void main(String[] args) throws URISyntaxException, ClientProtocolException, IOException {
        // TODO Auto-generated method stub
        UpdateItem d = new UpdateItem();
        d.updateCarData(1,"Saksham", "ACD-789",14);
    }

    public void updateCarData(int id,String name, String numb, int area) throws URISyntaxException, ClientProtocolException, IOException {
        CloseableHttpResponse response = null;
        URI uri = new URIBuilder().setScheme("http").setHost("localhost").setPort(8082)
                .setPath("/A00258753_NikitVaswani/valetParking/ParkingService/items").build();

        HttpPut httpPut = new HttpPut(uri);
        httpPut.setHeader("Accept", "text/html");
        CloseableHttpClient client = HttpClients.createDefault();

        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("id", String.valueOf(id)));
        nameValuePairs.add(new BasicNameValuePair("name", name));
        nameValuePairs.add(new BasicNameValuePair("numb", numb));
        nameValuePairs.add(new BasicNameValuePair("area", String.valueOf(area)));
  
        httpPut.setEntity(new UrlEncodedFormEntity(nameValuePairs));

        response = client.execute(httpPut);
        System.out.println(response.toString());

    }
}
